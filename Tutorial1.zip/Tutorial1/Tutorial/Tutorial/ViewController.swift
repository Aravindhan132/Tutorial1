//
//  ViewController.swift
//  Tutorial
//
//  Created by aravind-pt2199 on 26/05/19.
//  Copyright © 2019 aravind-pt2199. All rights reserved.
//

import UIKit

//Whole person class contans some property but we have card type is many soo we move to enum method lets see


enum Card {
    case MasterCard
    case PanCard
    case AadharCard
    case DebitCard
}

class Person {
    var name: String?
    var id: Int?
    var card: Card?
    
    
    //convinence let see
    
    
    init(name: String , id: Int , card: Card) {
        self.name = name
        self.id = id
        self.card = card
    }
    
    convenience init(name: String) {
        self.init(name: name, id: 9999, card: Card.MasterCard)
    }
}


class ViewController: UIViewController {

    var objectOne: Int = 1
    
    var objectTwo: Int = 2//changed to var
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //Works fine with static one
        
        //Let change the value
        
        objectOne = 3//changed awasome changes fine
        print(objectOne)
        
        //***********//
        objectTwo = 4//it throws error while run or compile
        
        objectTwo += 10 - 5//soo previous value is 4 + 10 - 5 = 9 is precidence
        //Cannot assign to property: 'objectTwo' is a 'let' constant
        print(objectTwo)//static
        
        
        let personObj1 = Person.init(name: "abc", id: 1, card: Card.MasterCard)
        let personObj1Clone = Person.init(name: "abcclone", id: 1, card: Card.MasterCard)
        let personObj2 = Person.init(name: "xyz", id: 1, card: Card.AadharCard)
        let personObj3 = Person.init(name: "def", id: 1, card: Card.PanCard)
        let personObj4 = Person.init(name: "hij", id: 1, card: Card.DebitCard)
        
        let personArray = [personObj1,personObj2,personObj3,personObj4,personObj1Clone]//It contains Arrray of person now we filter the array based on cards
        
      _ =  personArray.filter { (eachPerson) -> Bool in
            if eachPerson.card == Card.MasterCard {
                print(eachPerson.name)///abc contains master card
                return true
            }
            return false
        }
        
        
//        var personObj = Person.init(name: "abc")
//        print(personObj.id)//it ll show 9999 as value thz s convinence
    }


}

